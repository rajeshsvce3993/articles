import { Component, OnInit } from '@angular/core';
import { IndexService } from './index.service';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';


import { Globals } from '../globals';

@Component({
  selector: 'app-index-page',
  templateUrl: './index-page.component.html',
  styleUrls: ['./index-page.component.css']
})
export class IndexPageComponent implements OnInit {

 

  output: string;
  lastValue: number;
  firstValue: number;
  articles: any;
  flag: string;
 
  data=true;

  constructor( private indexService: IndexService,private router : Router,private globals: Globals) { }

  ngOnInit() {


    this.onView();

  }



  onView(){


this.firstValue=this.globals.first;
this.lastValue=this.globals.last;

    this.indexService.viewArticles(this.firstValue,this.lastValue).subscribe((data : any)=>
    {

      this.articles = data.value;

if(this.articles.length==0)
{

  this.data=false;
this.output="no more articles";


}
else
{

      this.articles = data.value;

this.globals.first=this.globals.last;
this.globals.last+=5;

     console.log(data.value);
}

    });

  }
  
login(){

  this.router.navigate(['/login']);

}

comments(item){

this.globals.articleId=item.articleId;
this.globals.likes=item.likes;
this.globals.dislikes=item.disLikes;

  this.router.navigate(['/comments']);

}


}
