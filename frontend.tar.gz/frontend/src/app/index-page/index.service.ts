import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable()
export class IndexService {


  readonly rootUrl = 'http://localhost:7000';

  constructor(private http: HttpClient) { }



  viewArticles(firstValue,lastValue)
  {
    
    var data = {
      "firstValue":firstValue,
      "lastValue":lastValue,

      
      
    };


var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json' });
return this.http.post(this.rootUrl + '/article',data, { headers: reqHeader });
  
  
  
  }


}
