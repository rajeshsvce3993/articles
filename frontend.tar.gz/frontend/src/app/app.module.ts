import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { Globals } from './globals'




import { AppComponent } from './app.component';
import { IndexPageComponent } from './index-page/index-page.component';


import { LoginComponent } from './login/login.component';
import { LoginService } from './login/login.service';
import { CommentsComponent } from './comments/comments.component';
import { ArticleComponent } from './article/article.component';
import { ArticleService } from './article/article.service';
import { IndexService } from './index-page/index.service';
import { CommentsService } from './comments/comments.service';



const appRoutes:Routes  =[
  /* {path:'',component: LoginFormComponent},
   {path:'dashboard',component: DashboardComponent},
   {path:'createemployee',component: CreateEmployeeComponent},
   {path:'uploadempproof',component: UploadEmployeeComponent},
   {path:'viewemployee',component: ViewEmployeeComponent},
   {path:'side',component: SidemenuComponent},
 ]*/
 
 
 { path: '', component: IndexPageComponent},
 { path: 'login', component:  LoginComponent},
// { path: 'menu/:type', component: MenuComponent},
 { path: 'comments', component:CommentsComponent},
 { path: 'create-article', component:ArticleComponent},
 
/*           children: [
             
             { path: 'menu', component: MenuComponent},
             
           ]
 }*/
 ]


@NgModule({
  declarations: [
    AppComponent,
    IndexPageComponent,
   
    LoginComponent,
    CommentsComponent,
    ArticleComponent
    ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
   
  ],
  providers: [LoginService,ArticleService,IndexService,Globals,CommentsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
