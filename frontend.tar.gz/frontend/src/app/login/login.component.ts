import { Component, OnInit } from '@angular/core';
import { LoginService } from './login.service';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { Globals } from '../globals';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  output: string;
login=true;
signin=false;

  constructor(private loginService: LoginService,private router : Router,private globals: Globals) { }

  ngOnInit() {
  }


signIn()
{

  this.login=false;
  this.signin=true;

}
logIn()
{

  this.login=true;
  this.signin=false;

}


onregister(name,email,password,mobile)
  {

    this.loginService.register(name,email,password,mobile).subscribe((data : any)=>
      {

        if(data.code==200)
        {
          this.output='Thankyou for your registration';
          
          

        }
        else if(data.code==300)
        {
          this.output='You already registered';

        }
        else
        {
          this.output='Something went wrong';


        }
     
      });
  

  }


  onlogin(email,password)
  {
    this.loginService.login(email,password).subscribe((data : any)=>
      {

        if(data.code==200)
        {
      
          this.globals.name=data.name;
          this.globals.token=data.token;
         // this.output='Login successfull';
      
        //  this.router.navigate(['/create-article']);
         if(this.globals.comments=='')
         {
        this.router.navigate(['/create-article']);
         }
         else
         {
          this.router.navigate(['/comments']);

         }

          

        }
        else if(data.code==201)
        {
          this.output='Please enter correct Mobile or Email and password';

        }
        else if(data.code==202)
        {
          this.output='Cannot find your account please register';


        }
        else
        {
          this.output='something went wrong';


        }
     
      });
  


  }



}
