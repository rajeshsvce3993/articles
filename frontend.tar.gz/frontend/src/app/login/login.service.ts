import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable()
export class LoginService {


  readonly rootUrl = 'http://localhost:7000';

  constructor(private http: HttpClient) { }

  register(name,email,password,mobile)
  {
    var data = {
      "names":name,
      "email":email,
      "password":password,
      "mobile":mobile,
      
      
    };


var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json' });
return this.http.post(this.rootUrl + '/register', data, { headers: reqHeader });
  
  
  
  }

  login(email,password)
  {
    var data = {
     
      "email":email,
      "password":password,
     
      
    };


var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json' });
return this.http.post(this.rootUrl + '/login', data, { headers: reqHeader });
  
  
  
  }



}
