
import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
 
  
    articleId : number=0;

    likes : number=0;
    dislikes : number=0;


    first : number=0;
    last : number=5;

name:any='';

comments:any='';

token:any='';


}