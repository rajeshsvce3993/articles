import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable()
export class CommentsService {


  readonly rootUrl = 'http://localhost:7000';

  constructor(private http: HttpClient) { }


  comments(id)
  {
    var data = {
      "id":id,

      
      
    };


var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json' });
return this.http.post(this.rootUrl + '/comments', data, { headers: reqHeader });
  
  
  
  }

  view(id,name,comments)
  {
    var data = {
      "id":id,
      "name":name,
      "comments":comments,

      
      
    };


var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json' });
return this.http.post(this.rootUrl + '/savecomments', data, { headers: reqHeader });
  
  
  
  }



  onLike(id,value,flag)
  {

    var data = {
      "id":id,
      "value":value,
      "flag":flag,
      

      
      
    };


var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json' });
return this.http.post(this.rootUrl + '/votes', data, { headers: reqHeader });
  
  

  }


}
