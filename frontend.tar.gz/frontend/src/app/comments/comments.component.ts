import { Component, OnInit } from '@angular/core';
import { CommentsService } from './comments.service';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { Globals } from '../globals';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  flag: string;
  value: number;
  name: any;
  second: boolean;
  first: boolean;
  output: string;
  comments: any;
  id: any;
  constructor(private commentsService: CommentsService,private router : Router,private globals: Globals) { }

  ngOnInit() {

this.viewComments();

  }



 


viewComments()
{

this.id=this.globals.articleId;

this.commentsService.comments(this.id).subscribe((data : any)=>
    {
      
     this.comments = data.value;

if(this.comments.length==0)
{

this.first=true;
this.second=false;

//this.output="Be the First to post a comment";

}
else{


  this.first=false;
this.second=true;


}



     


    });




}


onComment(comments)
{


  if(this.globals.token=='')
  {
  
  this.globals.comments="hai";
  
  this.router.navigate(['/login']);
  
  }
  else
  {


this.id=this.globals.articleId;
this.name=this.globals.name;

console.log(this.id);

this.commentsService.view(this.id,this.name,comments).subscribe((data : any)=>
    {
      
  

      this.comments = data.value;

     


    });

  }
 



}

create(comment)
{


if(this.globals.token=='')
{

this.globals.comments="hai";

this.router.navigate(['/login']);

}
else
{

this.id=this.globals.articleId;
this.name=this.globals.name;

this.commentsService.view(this.id,this.name,comment).subscribe((data : any)=>
    {
      
  

      this.output = "Successfully Post your comment";

     


    });


  }

  

}


like()
{

  this.id=this.globals.articleId;

this.value=this.globals.likes+1;

this.flag="a";

this.commentsService.onLike(this.id,this.value,this.flag).subscribe((data : any)=>
    {
      
  

     // this.output = "Successfully Post your comment";

     


    });

}

dislikes()
{

  this.id=this.globals.articleId;

this.value=this.globals.dislikes+1;

this.flag="b";

this.commentsService.onLike(this.id,this.value,this.flag).subscribe((data : any)=>
    {
      
  

     // this.output = "Successfully Post your comment";

     


    });

}



home()
{

  this.router.navigate(['']);

}



}
