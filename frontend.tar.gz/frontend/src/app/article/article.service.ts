import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable()
export class ArticleService {

  readonly rootUrl = 'http://localhost:7000';

  constructor(private http: HttpClient) { }


Create(author,title,link,description)
  {
    var data = {
      "author":author,
      "title":title,
      "link":link,
      "description":description,
      
      
      
    };


var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json' });
return this.http.post(this.rootUrl + '/create', data, { headers: reqHeader });
  
  
  
  }


}
