import { Component, OnInit } from '@angular/core';
import { ArticleService } from './article.service';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { Globals } from '../globals';

@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.css']
})
export class ArticleComponent implements OnInit {

  author: any;
  output: string;
  constructor(private articleService: ArticleService,private router : Router,private globals: Globals) { }

  ngOnInit() {
  }


  home()
  {

    this.router.navigate(['']);

  }

  onCreate(title,link,description)
  {

    this.author=this.globals.name;

console.log(this.globals.name);

    this.articleService.Create(this.author,title,link,description).subscribe((data : any)=>
      {

        if(data.code==200)
        {
          this.output='Your Article Has Been Posted Successfully';
          
          

        }
        else if(data.code==300)
        {
          this.output='You Already Posted This Article ';

        }
        else
        {
          this.output='Something went wrong';


        }
     
      });
  

  }


}
