var jwt = require('jsonwebtoken');
var mysql      = require('mysql');
var dbcon     = require('./connection.js');







 
exports.savecomments = function(req,res)

{

	var today = new Date();
	var id = req.body.id;
	var comments = req.body.comments;
	var  name= req.body.name;
	
	
	var postedOn=today;

  

var query="insert into comments(articleId,comments,commentBy,commentOn) values('"+id+"','"+comments+"','"+name+"','"+postedOn+"')";

				dbcon.connection.query(query, function (error, results, fields)
				 {
					if (error)
					{
					     	res.send
						({
							"code":400,
							"output":results
						})
				    	}
					else
					{
						res.send
						({
							"code":200,
							"output":"success"
						})
					}
				});
			
		
}


	
