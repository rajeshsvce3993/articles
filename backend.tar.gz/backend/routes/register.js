var jwt = require('jsonwebtoken');
var mysql      = require('mysql');
var dbcon     = require('./connection.js');







 
exports.register = function(req,res)

{

	var today = new Date();
	var email = req.body.email;
	var mobile = req.body.mobile;

    	var register=
	{
	      "name":req.body.names,
	      "email":req.body.email,
	      "password":req.body.password,
	      "mobile":req.body.mobile,
	      "createdOn":today
    	}

    	dbcon.connection.query('select count(*) as count from register where mobile="'+mobile+'" or email="'+email+'"', function (error, results, fields)
 	{
	       if (error)
		{
		     	res.send
			({
				"code":400,
				"output":"failed"
		        })
	    	}
		else
		{
			var count=results[0].count;
			if(count==0)
			{
				dbcon.connection.query('INSERT INTO register SET ?',register, function (error, results, fields)
				 {
					if (error)
					{
					     	res.send
						({
							"code":400,
							"output":"failed"
						})
				    	}
					else
					{
						
						  res.redirect('/login');
						
					}
				});
			}
			else
			{
				res.send
				({
					"code":300,
					"output":"duplicate"
				})
			}
		}
	});
}


	
