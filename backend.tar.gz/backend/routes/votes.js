var jwt = require('jsonwebtoken');
var mysql      = require('mysql');
var dbcon     = require('./connection.js');


exports.votes = function(req,res)
{
	   
	var id = req.body.id;
	var value = req.body.value;
	var flag = req.body.flag;
	
if(flag=='a')
{	

var query="update article set likes="+value+" where articleId="+id+"";

}
else
{
var query="update article set disLikes="+value+" where articleId="+id+"";


}
	   

	    dbcon.connection.query(query, function (error, results, fields)
	    {
      			if (error)
			 {
      
			       res.send
				({
					"code":400,
					"output":error
			      	})
			}
    			else
			{

			      	res.send
				({
					 "code":200,
					 "output":"success",
					 "value":results
					 
				});
			}
	   });
	
	   }
