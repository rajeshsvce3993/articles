var jwt = require('jsonwebtoken');
var mysql      = require('mysql');
var dbcon     = require('./connection.js');



exports.login = function(req,res)
{
	    var mobile= req.body.email;
	    var email= req.body.email;
	    var password = req.body.password;

	    var token = jwt.sign({'mobile':mobile,'password' : password},'authtoken');

var query="select * from register where mobile='"+mobile+"' or email='"+email+"'";

	    dbcon.connection.query(query, function (error, results, fields)
	    {
      			if (error)
			 {
      
			       res.send
				({
					"code":400,
					"output":"error ocurred"
			      	})
			}
    			else
			{

			      	if(results.length >0)
			      	{
					if(results[0].password == password)
					{
						  res.send
						 ({
							    "code":200,
							    "output":"login sucessfull",
							    "token":token,
							    "role":results[0].role,
							    "name":results[0].name,
							    "mobile":results[0].mobile
						  });
					}
					else
					{
						  res.send
						  ({
							    "code":201,
							    "output":"Mobile and password does not match"
						  });
					}
      				}
				else
				{
					 res.send
					({
						  "code":202,
						  "output":"Mobile does not exits"
					 });
				}
    			}
    	});
  }
