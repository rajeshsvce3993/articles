var jwt = require('jsonwebtoken');
var mysql      = require('mysql');
var dbcon     = require('./connection.js');


exports.article = function(req,res)
{
	   


	var firstValue = req.body.firstValue;
	var lastValue = req.body.lastValue;
	
var query="SELECT * from article limit "+firstValue+","+lastValue+"";

	   

	    dbcon.connection.query(query, function (error, results, fields)
	    {
      			if (error)
			 {
      
			       res.send
				({
					"code":400,
					"output":error
			      	})
			}
    			else
			{

			      	res.send
				({
					 "code":200,
					 "output":"success",
					 "value":results
					 
				});
			}
	   });
	
	   }
