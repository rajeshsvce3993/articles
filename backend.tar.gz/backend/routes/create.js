var jwt = require('jsonwebtoken');
var mysql      = require('mysql');
var dbcon     = require('./connection.js');







 
exports.create = function(req,res)

{

	var today = new Date();
	var link = req.body.link;
	var title = req.body.title;
	var author = req.body.author;
	var description = req.body.description;
	var postedOn=today;

    	/*var create=
	{
	     // "name":req.body.names,
	      "title":req.body.title,
	      "link":req.body.link,
	      "description":req.body.description,
	     // "id":req.body.id,
	        
	      "postedOn":today
    	}*/

    	dbcon.connection.query('select count(*) as count from article where link="'+link+'"', function (error, results, fields)
 	{
	       if (error)
		{
		     	res.send
			({
				"code":401,
				"output":"failed"
		        })
	    	}
		else
		{
			var count=results[0].count;
			if(count==0)
			{


var query="insert into article(name,title,link,description,postedOn,likes,disLikes) values('"+author+"','"+title+"','"+link+"','"+description+"','"+postedOn+"',0,0)";

				dbcon.connection.query(query, function (error, results, fields)
				 {
					if (error)
					{
					     	res.send
						({
							"code":400,
							"output":results
						})
				    	}
					else
					{
						res.send
						({
							"code":200,
							"output":"success"
						})
					}
				});
			}
			else
			{
				res.send
				({
					"code":300,
					"output":"duplicate"
				})
			}
		}
	});
}


	
