var jwt = require('jsonwebtoken');
var mysql      = require('mysql');
var dbcon     = require('./connection.js');


exports.comments = function(req,res)
{
	   
	   
var id = req.body.id;


var query="select * from comments where articleId="+id+"";


	    dbcon.connection.query(query, function (error, results, fields)
	    {
      			if (error)
			 {
      
			       res.send
				({
					"code":400,
					"output":"error ocurred"
			      	})
			}
    			else
			{

			      	res.send
				({
					 "code":200,
					 "output":"success",
					 "value":results
					 
				});
			}
	   });
	
	   }
