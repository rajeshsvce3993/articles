var express    = require("express");

var login = require('./routes/login');

var register = require('./routes/register');
var create = require('./routes/create');
var article = require('./routes/article');
var comments = require('./routes/comments');
var savecomments = require('./routes/savecomments');

var votes = require('./routes/votes');

//var saveorders = require('./routes/saveorders');




var bodyParser = require('body-parser');
var app = express();
var urlencodedParser=bodyParser.urlencoded({extended:false});

app.use(bodyParser.urlencoded({ limit: '50mb' }));
app.use(bodyParser.json({limit:'50mb'}));
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept,authentication-token, application/json,charset=utf-8");
    next();
});
var router = express.Router();
// test route
/*app.get('/', function(req, res) {
    res.send({ message: 'welcome to our upload module apis' });
});*/


/*app.get('/', function(req, res) {

  var name = 'hello';

  res.sendFile(path + "index.html", {name:name});

});*/


/*app.get('/', function(req, res) {
  res.render('index');
});*/



//route to handle.

app.post('/login',login.login);
app.post('/register',register.register);
app.post('/create',create.create);

app.post('/article',article.article);
app.post('/comments',comments.comments);
app.post('/savecomments',savecomments.savecomments);
app.post('/votes',votes.votes);


//app.post('/menu',menu.menu);
//app.post('/save',saveorders.saveorders);


app.use('/api', router);
app.listen(7000);


var express    = require("express");

var register = require('./routes/register');






